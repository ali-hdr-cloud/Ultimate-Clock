# Elya Android

Android APK wrapper for the Elya music player.

## App
- Name: Elya
- Package: `com.elya.music`
- Minimum Android: 7.0 (API 24)
- Target Android SDK: 35
- Version: 1.0.0

## Android integration
- Uses the Android system folder picker (`ACTION_OPEN_DOCUMENT_TREE`).
- Keeps read permission for the chosen folder.
- Recursively scans subfolders.
- Only adds playable audio longer than 60 seconds.
- Reads common metadata and embedded album art through `MediaMetadataRetriever`.
- Serves the selected local music into the WebView through an internal `https://elya.local/...` bridge.
- Includes a generic Android file chooser for cover art / backup import inputs.
- Does not request broad storage permission.
- Keeps the Elya web library / lyrics / playlists / stats UI in `app/src/main/assets/index.html`.

## Build
Open the folder in Android Studio and build `app`, or push it to GitHub.
The included GitHub Actions workflow builds a debug APK automatically and uploads it as the `Elya-APK` artifact.

The debug APK is installable for testing. A Play Store release should use your own release signing key.
