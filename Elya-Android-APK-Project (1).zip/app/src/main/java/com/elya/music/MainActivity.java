package com.elya.music;

import android.app.Activity;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.provider.DocumentsContract;
import android.provider.OpenableColumns;
import android.view.View;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.FileInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_TREE = 4101;
    private static final int REQ_FILE = 4102;
    private static final String PREFS = "elya_android";
    private static final String PREF_TREE = "music_tree_uri";
    private static final String APP_URL = "file:///android_asset/index.html";
    private static final String MEDIA_HOST = "elya.local";

    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Map<String, MediaEntry> mediaMap = new HashMap<>();

    static final class MediaEntry {
        final Uri uri;
        final String mime;
        final long size;
        final String name;
        MediaEntry(Uri uri, String mime, long size, String name) {
            this.uri = uri;
            this.mime = mime == null ? "audio/*" : mime;
            this.size = size;
            this.name = name == null ? "" : name;
        }
    }

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(5, 8, 13));
        window.setNavigationBarColor(Color.rgb(5, 8, 13));
        if (Build.VERSION.SDK_INT >= 23) {
            window.getDecorView().setSystemUiVisibility(0);
        }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(5, 8, 13));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setLoadsImagesAutomatically(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        if (Build.VERSION.SDK_INT >= 26) {
            s.setSafeBrowsingEnabled(true);
        }

        webView.addJavascriptInterface(new AndroidMusicBridge(), "AndroidMusic");
        webView.setWebChromeClient(new ElyaChromeClient());
        webView.setWebViewClient(new ElyaWebViewClient());
        webView.loadUrl(APP_URL);
    }

    private class AndroidMusicBridge {
        @JavascriptInterface
        public void chooseMusicFolder() {
            main.post(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);
                startActivityForResult(intent, REQ_TREE);
            });
        }

        @JavascriptInterface
        public void restoreMusicFolder() {
            String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TREE, null);
            if (value != null) {
                scanTree(Uri.parse(value), false);
            }
        }

        @JavascriptInterface
        public void rescanMusicFolder() {
            String value = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TREE, null);
            if (value != null) {
                scanTree(Uri.parse(value), false);
            } else {
                chooseMusicFolder();
            }
        }
    }

    private class ElyaChromeClient extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                         FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;

            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.setType("*/*");
            String[] accepts = params.getAcceptTypes();
            if (accepts != null && accepts.length > 0) {
                ArrayList<String> clean = new ArrayList<>();
                for (String a : accepts) if (a != null && !a.trim().isEmpty()) clean.add(a);
                if (clean.size() == 1) intent.setType(clean.get(0));
                else if (!clean.isEmpty()) intent.putExtra(Intent.EXTRA_MIME_TYPES, clean.toArray(new String[0]));
            }
            if (params.getMode() == FileChooserParams.MODE_OPEN_MULTIPLE) {
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
            }
            startActivityForResult(intent, REQ_FILE);
            return true;
        }
    }

    private class ElyaWebViewClient extends WebViewClient {
        @Override
        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (APP_URL.equals(url)) {
                String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_TREE, null);
                if (saved != null) {
                    main.postDelayed(() -> scanTree(Uri.parse(saved), false), 350);
                }
            }
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
            Uri u = request.getUrl();
            if (!"https".equals(u.getScheme()) || !MEDIA_HOST.equals(u.getHost())) return null;
            String path = u.getPath();
            if (path == null) return null;
            if (path.startsWith("/audio/")) {
                String token = path.substring("/audio/".length());
                MediaEntry entry;
                synchronized (mediaMap) { entry = mediaMap.get(token); }
                if (entry == null) return null;
                try {
                    return openAudioResponse(entry, request.getRequestHeaders().get("Range"));
                } catch (Exception e) {
                    return null;
                }
            }
            if (path.startsWith("/cover/")) {
                String token = path.substring("/cover/".length());
                MediaEntry entry;
                synchronized (mediaMap) { entry = mediaMap.get(token); }
                if (entry == null) return null;
                byte[] art = readEmbeddedPicture(entry.uri);
                if (art == null) return null;
                return new WebResourceResponse("image/jpeg", null, new ByteArrayInputStream(art));
            }
            return null;
        }
    }

    private WebResourceResponse openAudioResponse(MediaEntry entry, String range) throws Exception {
        ContentResolver cr = getContentResolver();
        long total = entry.size;
        long start = 0;
        long end = total > 0 ? total - 1 : -1;
        boolean partial = false;

        if (range != null && range.startsWith("bytes=") && total > 0) {
            String spec = range.substring(6).split(",")[0].trim();
            String[] parts = spec.split("-", 2);
            if (!parts[0].isEmpty()) start = Long.parseLong(parts[0]);
            if (parts.length > 1 && !parts[1].isEmpty()) end = Math.min(total - 1, Long.parseLong(parts[1]));
            if (end < start) end = total - 1;
            partial = true;
        }

        InputStream base = cr.openInputStream(entry.uri);
        if (base == null) return null;
        long skipped = 0;
        while (skipped < start) {
            long n = base.skip(start - skipped);
            if (n <= 0) break;
            skipped += n;
        }

        InputStream body = base;
        long contentLength = total > 0 ? (partial ? end - start + 1 : total) : -1;
        if (contentLength >= 0) body = new LimitedInputStream(base, contentLength);

        Map<String, String> headers = new HashMap<>();
        headers.put("Accept-Ranges", "bytes");
        headers.put("Cache-Control", "no-store");
        if (contentLength >= 0) headers.put("Content-Length", String.valueOf(contentLength));
        if (partial && total > 0) {
            headers.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            return new WebResourceResponse(entry.mime, null, 206, "Partial Content", headers, body);
        }
        return new WebResourceResponse(entry.mime, null, 200, "OK", headers, body);
    }

    private static class LimitedInputStream extends FilterInputStream {
        private long remaining;
        LimitedInputStream(InputStream in, long remaining) {
            super(in);
            this.remaining = remaining;
        }
        @Override public int read() throws IOException {
            if (remaining <= 0) return -1;
            int v = super.read();
            if (v >= 0) remaining--;
            return v;
        }
        @Override public int read(byte[] b, int off, int len) throws IOException {
            if (remaining <= 0) return -1;
            len = (int)Math.min(len, remaining);
            int n = super.read(b, off, len);
            if (n > 0) remaining -= n;
            return n;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQ_TREE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Uri tree = data.getData();
                int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                try {
                    getContentResolver().takePersistableUriPermission(tree, flags & Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(PREF_TREE, tree.toString()).apply();
                scanTree(tree, true);
            }
            return;
        }

        if (requestCode == REQ_FILE) {
            if (fileCallback == null) return;
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null) {
                if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    result = new Uri[n];
                    for (int i = 0; i < n; i++) result[i] = data.getClipData().getItemAt(i).getUri();
                } else if (data.getData() != null) {
                    result = new Uri[]{data.getData()};
                }
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    private void scanTree(Uri treeUri, boolean userInitiated) {
        io.execute(() -> {
            try {
                String folderName = queryName(treeUri);
                if (folderName == null || folderName.isEmpty()) folderName = "Music folder";
                final String fn = folderName;
                js("window.__elyaNativeScanStarted && window.__elyaNativeScanStarted(" + JSONObject.quote(fn) + ");");

                ArrayList<JSONObject> items = new ArrayList<>();
                synchronized (mediaMap) { mediaMap.clear(); }

                String rootId = DocumentsContract.getTreeDocumentId(treeUri);
                scanDocumentChildren(treeUri, rootId, "", items);

                JSONArray arr = new JSONArray();
                for (JSONObject o : items) arr.put(o);
                js("window.__elyaReceiveNativeLibrary && window.__elyaReceiveNativeLibrary("
                        + arr.toString() + "," + JSONObject.quote(fn) + ");");
            } catch (Exception e) {
                js("window.__elyaNativeScanError && window.__elyaNativeScanError("
                        + JSONObject.quote("Could not read this folder. Choose it again if Android removed permission.") + ");");
            }
        });
    }

    private void scanDocumentChildren(Uri treeUri, String parentDocumentId, String relPath,
                                      ArrayList<JSONObject> out) {
        Uri children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, parentDocumentId);
        String[] projection = new String[]{
                DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                DocumentsContract.Document.COLUMN_MIME_TYPE,
                DocumentsContract.Document.COLUMN_SIZE,
                DocumentsContract.Document.COLUMN_LAST_MODIFIED
        };

        try (Cursor c = getContentResolver().query(children, projection, null, null, null)) {
            if (c == null) return;
            int idCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DOCUMENT_ID);
            int nameCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_DISPLAY_NAME);
            int mimeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_MIME_TYPE);
            int sizeCol = c.getColumnIndex(DocumentsContract.Document.COLUMN_SIZE);

            while (c.moveToNext()) {
                String docId = idCol >= 0 ? c.getString(idCol) : null;
                String name = nameCol >= 0 ? c.getString(nameCol) : "";
                String mime = mimeCol >= 0 ? c.getString(mimeCol) : "";
                long size = sizeCol >= 0 && !c.isNull(sizeCol) ? c.getLong(sizeCol) : -1;
                if (docId == null) continue;

                if (DocumentsContract.Document.MIME_TYPE_DIR.equals(mime)) {
                    scanDocumentChildren(treeUri, docId, relPath + name + "/", out);
                    continue;
                }
                if (!isAudio(name, mime)) continue;

                Uri docUri = DocumentsContract.buildDocumentUriUsingTree(treeUri, docId);
                JSONObject item = describeAudio(docUri, relPath + name, name, mime, size);
                if (item != null) out.add(item);
            }
        } catch (Exception ignored) {}
    }

    private JSONObject describeAudio(Uri uri, String relPath, String fileName, String mime, long size) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(this, uri);
            long durationMs = parseLong(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION));
            if (durationMs <= 60000) return null;

            String title = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE));
            String artist = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST));
            String album = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM));
            String genre = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE));
            String year = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_YEAR));
            String track = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_CD_TRACK_NUMBER));
            String albumArtist = clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUMARTIST));
            String discNo = Build.VERSION.SDK_INT >= 23
                    ? clean(mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DISC_NUMBER)) : "";

            String key = uri.toString();
            String token = Integer.toHexString(key.hashCode()) + "_" + Integer.toHexString(relPath.hashCode());
            synchronized (mediaMap) { mediaMap.put(token, new MediaEntry(uri, normalizeMime(fileName, mime), size, fileName)); }

            JSONObject o = new JSONObject();
            o.put("fileKey", key);
            o.put("fileName", fileName);
            o.put("title", title.isEmpty() ? stripExt(fileName) : title);
            o.put("artist", artist);
            o.put("album", album);
            o.put("genre", genre);
            o.put("year", year);
            o.put("trackNo", track);
            o.put("albumArtist", albumArtist);
            o.put("discNo", discNo);
            o.put("duration", durationMs / 1000.0);
            o.put("url", "https://" + MEDIA_HOST + "/audio/" + token);

            byte[] art = mmr.getEmbeddedPicture();
            if (art != null && art.length > 0) {
                o.put("cover", "https://" + MEDIA_HOST + "/cover/" + token);
            }
            return o;
        } catch (Exception e) {
            return null;
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }
    }

    private byte[] readEmbeddedPicture(Uri uri) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(this, uri);
            return mmr.getEmbeddedPicture();
        } catch (Exception e) {
            return null;
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }
    }

    private String queryName(Uri uri) {
        try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (c != null && c.moveToFirst()) return c.getString(0);
        } catch (Exception ignored) {}
        return null;
    }

    private static boolean isAudio(String name, String mime) {
        if (mime != null && mime.toLowerCase(Locale.US).startsWith("audio/")) return true;
        String ext = "";
        int dot = name == null ? -1 : name.lastIndexOf('.');
        if (dot >= 0) ext = name.substring(dot + 1).toLowerCase(Locale.US);
        return ext.matches("mp3|m4a|aac|wav|ogg|oga|opus|flac|webm|mp4|aif|aiff|mka");
    }

    private static String normalizeMime(String name, String mime) {
        if (mime != null && mime.startsWith("audio/")) return mime;
        String ext = MimeTypeMap.getFileExtensionFromUrl(name == null ? "" : name);
        String guessed = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext == null ? "" : ext.toLowerCase(Locale.US));
        return guessed != null ? guessed : "audio/*";
    }

    private static String clean(String s) { return s == null ? "" : s.trim(); }
    private static long parseLong(String s) {
        try { return Long.parseLong(s == null ? "0" : s); } catch (Exception e) { return 0; }
    }
    private static String stripExt(String name) {
        if (name == null) return "Unknown Song";
        int dot = name.lastIndexOf('.');
        return dot > 0 ? name.substring(0, dot) : name;
    }

    private void js(String code) {
        main.post(() -> {
            if (webView != null) webView.evaluateJavascript(code, null);
        });
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        if (webView != null) {
            webView.loadUrl("about:blank");
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
